/****
 * project settings and some other
 ****/
#define PROJ_DEBUG

#define UARTPORTNAME_NMOTIONCTRL     "/dev/ttyUSB1"
#define UARTPORTNAME_OFPS1           "/dev/ttyUSB0"
#define UARTPORTNAME_PS              "/dev/ttyUSB1"
#define UARTPORTNAME_PBUTTING        "/dev/ttyUSB1"
